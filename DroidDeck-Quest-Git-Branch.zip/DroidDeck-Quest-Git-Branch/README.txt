DroidDeck Quest Git branch export

Contents:
- DroidDeck-Quest.bundle: real Git branch, with the original upstream base as prerequisite.
- 0001-Quest-compatibility.patch: alternative git-am patch, including binary changes.

IMPORT THE BRANCH
Unzip this folder. In a terminal inside this folder run:

  git clone https://github.com/Droid-Deck/DroidDeck.git DroidDeck
  cd DroidDeck
  git fetch ../DroidDeck-Quest.bundle refs/heads/quest/horizon-compat:refs/heads/quest/horizon-compat
  git switch quest/horizon-compat

For an existing upstream clone, fetch the bundle by its absolute path instead.
The repository must contain upstream commit:
  a58b0ac3e0ea9dc588a162df8ddf04864715dee2
If absent from a shallow clone, fetch that commit from origin first.

ALTERNATIVE: APPLY THE PATCH (do not also import the bundle)
From an upstream clone containing the base commit:

  git switch -c quest/horizon-compat a58b0ac3e0ea9dc588a162df8ddf04864715dee2
  git am /absolute/path/to/0001-Quest-compatibility.patch

Branch tip: 13756fed818693b9f7d3ad701c89b660588ffc84
Read QUEST-BRANCH.txt and QUEST-PORT.txt after importing.

This is an offline export. No branch was pushed to GitHub.
It contains the existing Quest 3 changes, not a new Quest 2 port.
A .branch importer could not be found in the 0.3.2 app source. An example
file or the intended import screen is needed to implement that deliverable.
This bundle cannot be imported into DroidDeck as an app/runtime update.

Host tests passed. APK compilation and headset tests were not repeated.
